#!/bin/bash
# Quick test script - load an audio file into the MP3 Trimmer app
APP="/Users/daddy/hermesworkspace/mp3-trimmer/.build/debug/MP3Trimmer"

if [ -z "$1" ]; then
    echo "Usage: ./test-trimmer.sh <audio-file>"
    echo "Example: ./test-trimmer.sh /Users/daddy/Downloads/test.mp3"
    exit 1
fi

if [ ! -f "$1" ]; then
    echo "Error: File not found: $1"
    exit 1
fi

echo "Loading: $1"
echo "This will open the file in MP3 Trimmer"
echo "Note: Drop the file onto the app window manually"
echo ""
echo "Starting app..."
open "$APP"

// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "MP3Trimmer",
    platforms: [
        .macOS(.v13)
    ],
    targets: [
        .executableTarget(
            name: "MP3Trimmer",
            dependencies: [],
            path: "Sources"
        )
    ]
)

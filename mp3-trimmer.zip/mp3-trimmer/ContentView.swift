import SwiftUI
import AVFoundation
import UniformTypeIdentifiers

struct WaveformView: View {
    let duration: Double
    let startTime: Double
    let endTime: Double
    let currentTime: Double
    let isPlaying: Bool
    
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                // Background waveform
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.black.opacity(0.4))
                    .frame(height: 140)
                    .overlay(
                        HStack(spacing: 2) {
                            ForEach(0..<80, id: \.self) { i in
                                let height = CGFloat.random(in: 20...120)
                                Capsule()
                                    .fill(Color.cyan.opacity(0.8))
                                    .frame(width: 3, height: height)
                            }
                        }
                    )
                
                // Trimming selection (yellow box)
                let selectionStart = (startTime / max(duration, 1)) * geometry.size.width
                let selectionEnd = (endTime / max(duration, 1)) * geometry.size.width
                let selectionWidth = selectionEnd - selectionStart
                
                RoundedRectangle(cornerRadius: 4)
                    .stroke(Color.yellow, lineWidth: 3)
                    .frame(width: max(selectionWidth, 50), height: 150)
                    .offset(x: selectionStart)
                
                // Playhead
                let playheadX = (currentTime / max(duration, 1)) * geometry.size.width
                Rectangle()
                    .fill(Color.red)
                    .frame(width: 2, height: 150)
                    .offset(x: playheadX)
                
                // Draggable handles
                HandleView(position: selectionStart, isLeading: true) { _ in
                    // Handle drag for start
                }
                .offset(x: 0)
                
                HandleView(position: selectionEnd, isLeading: false) { _ in
                    // Handle drag for end
                }
                .offset(x: selectionWidth)
            }
        }
        .frame(height: 160)
    }
}

struct HandleView: View {
    let position: Double
    let isLeading: Bool
    let onDrag: (Double) -> Void
    
    var body: some View {
        Rectangle()
            .fill(Color.yellow)
            .frame(width: 12, height: 30)
            .cornerRadius(3)
            .offset(y: -40)
            .shadow(radius: 2)
            .gesture(
                DragGesture()
                    .onChanged { value in
                        onDrag(value.location.x)
                    }
            )
    }
}

struct ContentView: View {
    @StateObject private var viewModel = AudioEditorViewModel()
    @State private var showingExportPanel = false
    @State private var exportResult: String? = nil
    
    var body: some View {
        VStack(spacing: 0) {
            // Title bar (no window controls)
            HStack {
                Text("MP3 Trimmer")
                    .font(.headline)
                    .foregroundColor(.white)
                Spacer()
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 12)
            .background(Color(red: 0.08, green: 0.08, blue: 0.10))
            
            // Main content
            HStack(spacing: 0) {
                // Left: Main Workspace
                VStack(spacing: 20) {
                    Spacer()
                    
                    // Drop zone or waveform
                    if viewModel.fileName == "No file selected" {
                        // Drop zone
                        VStack {
                            Image(systemName: "wand.and.stars")
                                .font(.system(size: 48))
                                .foregroundColor(.cyan)
                                .padding()
                            Text("Drop an audio file here")
                                .font(.title3)
                                .foregroundColor(.white)
                            Text("Supports MP3, M4A, WAV, and more")
                                .font(.caption)
                                .foregroundColor(.gray)
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 200)
                        .background(Color.black.opacity(0.2))
                        .cornerRadius(12)
                        .padding(.horizontal, 40)
                        .onDrop(of: [UTType.audio], isTargeted: nil) { providers in
                            providers.first?.loadFileURL { url, _ in
                                if let url = url {
                                    viewModel.loadAudio(from: url)
                                }
                            }
                            return true
                        }
                    } else {
                        // Waveform view
                        WaveformView(
                            duration: viewModel.assetDuration,
                            startTime: viewModel.startTime,
                            endTime: viewModel.endTime,
                            currentTime: viewModel.audioPlayer?.currentTime ?? 0,
                            isPlaying: viewModel.isPlaying
                        )
                        .padding(.horizontal, 40)
                    }
                    
                    // Transport controls
                    HStack(spacing: 20) {
                        Button(action: {
                            if viewModel.isPlaying {
                                viewModel.stopPlayback()
                            } else {
                                viewModel.togglePlayPause()
                            }
                        }) {
                            Image(systemName: viewModel.isPlaying ? "pause.fill" : "play.fill")
                                .font(.title2)
                                .foregroundColor(.white)
                                .padding(16)
                                .background(Circle().fill(Color.white.opacity(0.15)))
                        }
                        
                        // Time display
                        Text("\(viewModel.formatTime(viewModel.startTime))  →  \(viewModel.formatTime(viewModel.endTime))")
                            .font(.system(.body, design: .monospaced))
                            .foregroundColor(.cyan)
                    }
                    .padding(.top, 10)
                    
                    Spacer()
                    
                    // Bottom bar
                    HStack {
                        Text("File: \(viewModel.fileName)")
                            .foregroundColor(.gray)
                            .font(.caption)
                        
                        Spacer()
                        
                        Text("Duration: \(viewModel.formatTime(viewModel.endTime - viewModel.startTime))")
                            .foregroundColor(.gray)
                            .font(.caption)
                        
                        Spacer()
                        
                        Button("Export") {
                            showingExportPanel = true
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(viewModel.fileName == "No file selected")
                    }
                    .padding()
                    .background(Color(red: 0.08, green: 0.08, blue: 0.10))
                }
                .background(Color(red: 0.12, green: 0.12, blue: 0.14))
                
                Divider()
                    .background(Color.gray.opacity(0.3))
                
                // Right sidebar
                VStack(alignment: .leading, spacing: 20) {
                    // Mode selection
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Operation Mode")
                            .font(.headline)
                            .foregroundColor(.white)
                        
                        ForEach(AudioEditorViewModel.ExtractionMode.allCases) { mode in
                            Button(action: {
                                viewModel.extractionMode = mode
                            }) {
                                HStack {
                                    Image(systemName: viewModel.extractionMode == mode ? "checkmark.circle.fill" : "circle")
                                        .foregroundColor(.cyan)
                                    Text(mode.rawValue)
                                        .foregroundColor(.white)
                                }
                                .padding()
                                .background(viewModel.extractionMode == mode ? Color.cyan.opacity(0.2) : Color.clear)
                                .cornerRadius(8)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    
                    Divider()
                        .background(Color.gray.opacity(0.3))
                    
                    // Trim controls
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Trim Points")
                            .font(.headline)
                            .foregroundColor(.white)
                        
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text("Start")
                                    .foregroundColor(.gray)
                                    .font(.caption)
                                Spacer()
                                Text(viewModel.formatTime(viewModel.startTime))
                                    .font(.system(.body, design: .monospaced))
                                    .foregroundColor(.cyan)
                            }
                            
                            HStack {
                                Text("End")
                                    .foregroundColor(.gray)
                                    .font(.caption)
                                Spacer()
                                Text(viewModel.formatTime(viewModel.endTime))
                                    .font(.system(.body, design: .monospaced))
                                    .foregroundColor(.cyan)
                            }
                        }
                        
                        // Time inputs
                        HStack {
                            TextField("Start", value: $viewModel.startTime, format: .number)
                                .textFieldStyle(.roundedBorder)
                                .disabled(viewModel.fileName == "No file selected")
                            
                            Text("→")
                                .foregroundColor(.gray)
                            
                            TextField("End", value: $viewModel.endTime, format: .number)
                                .textFieldStyle(.roundedBorder)
                                .disabled(viewModel.fileName == "No file selected")
                        }
                    }
                    
                    Spacer()
                    
                    // Tips
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Tips")
                            .font(.caption)
                            .foregroundColor(.gray)
                            .textCase(.uppercase)
                        
                        Text("• Drag the yellow handles on the waveform to trim")
                            .font(.caption)
                            .foregroundColor(.gray)
                        
                        Text("• Press Space to play/pause")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                }
                .padding(20)
                .frame(width: 280)
                .background(Color(red: 0.16, green: 0.16, blue: 0.18))
            }
        }
        .frame(minWidth: 900, minHeight: 600)
        .fileImporter(
            isPresented: $showingExportPanel,
            allowedContentTypes: [UTType.audio],
            allowsMultipleSelection: false
        ) { result in
            switch result {
            case .success(let urls):
                if let url = urls.first {
                    viewModel.exportAudio(to: url) { outcome in
                        switch outcome {
                        case .success(let exportedURL):
                            exportResult = "Exported to: \(exportedURL.lastPathComponent)"
                        case .failure(let error):
                            exportResult = "Export failed: \(error.localizedDescription)"
                        }
                    }
                }
            case .failure:
                break
            }
        }
        .alert("Export Result", isPresented: .constant(exportResult != nil)) {
            Button("OK") {
                exportResult = nil
            }
        } message: {
            if let result = exportResult {
                Text(result)
            }
        }
    }
}

struct MP3TrimmerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .windowStyle(.hiddenTitleBar)
        .windowResizability(.contentSize)
    }
}

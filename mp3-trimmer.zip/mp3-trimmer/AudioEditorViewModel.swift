import Foundation
import AVFoundation
import SwiftUI
import Combine

class AudioEditorViewModel: ObservableObject {
    @Published var audioPlayer: AVAudioPlayer?
    @Published var isPlaying = false
    @Published var assetDuration: Double = 0.0
    @Published var startTime: Double = 0.0
    @Published var endTime: Double = 0.0
    @Published var fileName: String = "No file selected"
    @Published var extractionMode: ExtractionMode = .extractSelected
    @Published var isExporting = false
    @Published var exportProgress: Double = 0.0
    
    private var audioURL: URL?
    private var cancellables = Set<AnyCancellable>()

    enum ExtractionMode: String, CaseIterable, Identifiable {
        case extractSelected = "Extract Selected"
        case deleteSelected = "Delete Selected"
        
        var id: String { rawValue }
    }

    func loadAudio(from url: URL) {
        self.audioURL = url
        self.fileName = url.lastPathComponent
        self.startTime = 0.0
        self.endTime = 0.0
        
        Task {
            do {
                let asset = AVAsset(url: url)
                self.assetDuration = try await asset.load(.duration).seconds
                await MainActor.run {
                    self.endTime = self.assetDuration
                    do {
                        self.audioPlayer = try AVAudioPlayer(contentsOf: url)
                        self.audioPlayer?.prepareToPlay()
                    } catch {
                        print("Failed to load audio player: \(error.localizedDescription)")
                    }
                }
            } catch {
                print("Failed to load asset: \(error.localizedDescription)")
            }
        }
    }

    func togglePlayPause() {
        guard let player = audioPlayer else { return }
        if isPlaying {
            player.pause()
            isPlaying = false
        } else {
            player.play()
            isPlaying = true
        }
    }

    func stopPlayback() {
        audioPlayer?.stop()
        isPlaying = false
    }

    func exportAudio(to outputURL: URL, completion: @escaping (Result<URL, Error>) -> Void) {
        guard let audioURL = audioURL else { return }
        
        isExporting = true
        exportProgress = 0.0
        
        let asset = AVAsset(url: audioURL)
        let presetName: AVAssetExportPreset
        
        switch extractionMode {
        case .extractSelected:
            presetName = AVAssetExportPresetAppleM4A
        case .deleteSelected:
            // For delete mode, we need to keep everything except the selected range
            // This is more complex - for now use standard export and invert later
            presetName = AVAssetExportPresetAppleM4A
        }
        
        guard let exportSession = AVAssetExportSession(asset: asset, presetName: presetName) else {
            completion(.failure(NSError(domain: "ExportError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to create export session"])))
            isExporting = false
            return
        }
        
        exportSession.outputURL = outputURL
        exportSession.outputFileType = .m4a
        
        let startCMTime = CMTime(seconds: startTime, preferredTimescale: 600)
        let endCMTime = CMTime(seconds: endTime, preferredTimescale: 600)
        exportSession.timeRange = CMTimeRange(start: startCMTime, end: endCMTime)
        
        exportSession.exportAsynchronously {
            DispatchQueue.main.async {
                switch exportSession.status {
                case .completed:
                    self.isExporting = false
                    self.exportProgress = 1.0
                    completion(.success(outputURL))
                case .failed, .cancelled:
                    self.isExporting = false
                    if let error = exportSession.error {
                        completion(.failure(error))
                    }
                default:
                    break
                }
            }
        }
    }
    
    func formatTime(_ seconds: Double) -> String {
        let mins = Int(seconds) / 60
        let secs = Int(seconds) % 60
        let milliseconds = Int((seconds.truncatingRemainder(dividingBy: 1)) * 100)
        return String(format: "%02d:%02d.%02d", mins, secs, milliseconds)
    }
}

import Foundation
import AVFoundation
import SwiftUI
import Combine

class AudioEditorViewModel: ObservableObject {
    @Published var audioPlayer: AVAudioPlayer?
    @Published var isPlaying = false
    @Published var assetDuration: Double = 0.0
    @Published var startTime: Double = 0.0
    @Published var endTime: Double = 0.0
    @Published var fileName: String = "No file selected"
    @Published var extractionMode: ExtractionMode = .extractSelected
    @Published var isExporting = false
    @Published var exportProgress: Double = 0.0
    @Published var currentTime: Double = 0.0
    @Published var waveformSamples: [Float] = []
    
    private var audioURL: URL?
    private var cancellables = Set<AnyCancellable>()
    private var timer: Timer?

    enum ExtractionMode: String, CaseIterable, Identifiable {
        case extractSelected = "Extract Selected"
        case deleteSelected = "Delete Selected"
        
        var id: String { rawValue }
    }
    
    func loadAudio(from url: URL) {
        extractWaveform(from: url)
        startPlayback(from: url)
    }
    
    func extractWaveform(from url: URL) {
        Task {
            let asset = AVAsset(url: url)
            guard let track = try? await asset.loadTracks(withMediaType: .audio).first else {
                await MainActor.run { self.waveformSamples = [] }
                return
            }
            
            do {
                let reader = try AVAssetReader(asset: asset)
                let outputSettings: [String: Any] = [
                    AVFormatIDKey: kAudioFormatLinearPCM,
                    AVLinearPCMBitDepthKey: 16,
                    AVLinearPCMIsBigEndianKey: false,
                    AVLinearPCMIsFloatKey: false,
                    AVLinearPCMIsNonInterleaved: false
                ]
                
                let trackOutput = AVAssetReaderTrackOutput(track: track, outputSettings: outputSettings)
                guard reader.canAdd(trackOutput) else { return }
                reader.add(trackOutput)
                reader.startReading()
                
                var samples: [Float] = []
                let targetSampleCount = 100
                var accumulator: Float = 0
                var count = 0
                
                while reader.status == .reading, let sampleBuffer = trackOutput.copyNextSampleBuffer() {
                    guard let blockBuffer = CMSampleBufferGetDataBuffer(sampleBuffer) else { continue }
                    var length = 0
                    var dataPointer: UnsafeMutablePointer<Int8>? = nil
                    CMBlockBufferGetDataPointer(blockBuffer, atOffset: 0, lengthAtOffsetOut: &length, totalLengthOut: nil, dataPointerOut: &dataPointer)
                    
                    if let ptr = dataPointer {
                        ptr.withMemoryRebound(to: Int16.self, capacity: length / 2) { int16Ptr in
                            let audioSamples = UnsafeBufferPointer(start: int16Ptr, count: length / 2)
                            for sample in audioSamples {
                                accumulator += abs(Float(sample) / 32768.0)
                                count += 1
                                
                                if count >= 2000 {
                                    samples.append(accumulator / Float(count))
                                    accumulator = 0
                                    count = 0
                                }
                            }
                        }
                    }
                }
                
                reader.cancelReading()
                
                // Downsample to exactly 100 points for display
                let displayCount = 100
                if samples.count > displayCount {
                    let chunkSize = samples.count / displayCount
                    var downsampled: [Float] = []
                    for i in 0..<displayCount {
                        let start = i * chunkSize
                        let end = min(start + chunkSize, samples.count)
                        let sum = samples[start..<end].reduce(0, +)
                        downsampled.append(sum / Float(end - start))
                    }
                    samples = downsampled
                }
                
                await MainActor.run {
                    self.waveformSamples = samples
                    print("Waveform extracted: \(samples.count) samples")
                }
            } catch {
                print("Waveform extraction failed: \(error.localizedDescription)")
                await MainActor.run { self.waveformSamples = [] }
            }
        }
    }
    
    func startPlayback(from url: URL) {
        audioPlayer?.stop()
        timer?.invalidate()
        
        self.audioURL = url
        self.fileName = url.lastPathComponent
        self.startTime = 0.0
        self.endTime = 0.0
        self.currentTime = 0.0
        self.isPlaying = false
        
        Task {
            do {
                let asset = AVAsset(url: url)
                self.assetDuration = try await asset.load(.duration).seconds
                await MainActor.run {
                    self.endTime = self.assetDuration
                    do {
                        self.audioPlayer = try AVAudioPlayer(contentsOf: url)
                        self.audioPlayer?.volume = 1.0
                        self.setupPlaybackTimer()
                    } catch {
                        print("Failed to load audio: \(error.localizedDescription)")
                    }
                }
            } catch {
                print("Failed to load asset: \(error.localizedDescription)")
            }
        }
    }
    
    private func setupPlaybackTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            guard let self = self, let player = self.audioPlayer, player.isPlaying else { return }
            DispatchQueue.main.async {
                self.currentTime = player.currentTime
            }
        }
    }

    func togglePlayPause() {
        guard let player = audioPlayer else { return }
        if isPlaying {
            player.pause()
            isPlaying = false
        } else {
            player.play()
            isPlaying = true
        }
    }

    func stopPlayback() {
        audioPlayer?.stop()
        isPlaying = false
        currentTime = 0
    }

    func exportAudio(to outputURL: URL, completion: @escaping (Result<URL, Error>) -> Void) {
        guard let audioURL = audioURL else { return }
        
        isExporting = true
        exportProgress = 0.0
        
        let asset = AVAsset(url: audioURL)
        
        guard let exportSession = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A) else {
            completion(.failure(NSError(domain: "ExportError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to create export session"])))
            isExporting = false
            return
        }
        
        exportSession.outputURL = outputURL
        exportSession.outputFileType = .m4a
        
        let startCMTime = CMTime(seconds: startTime, preferredTimescale: 600)
        let endCMTime = CMTime(seconds: endTime, preferredTimescale: 600)
        exportSession.timeRange = CMTimeRange(start: startCMTime, end: endCMTime)
        
        exportSession.exportAsynchronously {
            DispatchQueue.main.async {
                switch exportSession.status {
                case .completed:
                    self.isExporting = false
                    self.exportProgress = 1.0
                    completion(.success(outputURL))
                case .failed, .cancelled:
                    self.isExporting = false
                    if let error = exportSession.error {
                        completion(.failure(error))
                    }
                default:
                    break
                }
            }
        }
    }
    
    func formatTime(_ seconds: Double) -> String {
        let mins = Int(seconds) / 60
        let secs = Int(seconds) % 60
        let milliseconds = Int((seconds.truncatingRemainder(dividingBy: 1)) * 100)
        return String(format: "%02d:%02d.%02d", mins, secs, milliseconds)
    }
}

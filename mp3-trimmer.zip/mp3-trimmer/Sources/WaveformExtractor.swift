import AVFoundation
import Foundation

class WaveformExtractor {
    static func extractSamples(from url: URL, sampleCount: Int, completion: @escaping ([Float]) -> Void) {
        let asset = AVAsset(url: url)
        
        Task {
            guard let track = try? await asset.loadTracks(withMediaType: .audio).first else {
                await MainActor.run { completion([]) }
                return
            }
            
            do {
                let reader = try AVAssetReader(asset: asset)
                let outputSettings: [String: Any] = [
                    AVFormatIDKey: kAudioFormatLinearPCM,
                    AVLinearPCMBitDepthKey: 16,
                    AVLinearPCMIsBigEndianKey: false,
                    AVLinearPCMIsFloatKey: false,
                    AVLinearPCMIsNonInterleaved: false
                ]
                
                let trackOutput = AVAssetReaderTrackOutput(track: track, outputSettings: outputSettings)
                reader.add(trackOutput)
                reader.startReading()
                
                var accumulatedData = Data()
                while reader.status == .reading {
                    if let sampleBuffer = trackOutput.copyNextSampleBuffer(),
                       let blockBuffer = CMSampleBufferGetDataBuffer(sampleBuffer) {
                        var length = 0
                        var dataPointer: UnsafeMutablePointer<Int8>? = nil
                        CMBlockBufferGetDataPointer(blockBuffer, atOffset: 0, lengthAtOffsetOut: &length, totalLengthOut: nil, dataPointerOut: &dataPointer)
                        if let ptr = dataPointer {
                            accumulatedData.append(UnsafeBufferPointer(start: ptr, count: length))
                        }
                    }
                }
                
                reader.cancelReading()
                
                let samples = processRawData(accumulatedData, targetCount: sampleCount)
                print("Extracted \(samples.count) samples from \(accumulatedData.count) bytes")
                await MainActor.run { completion(samples) }
            } catch {
                print("Waveform extraction failed: \(error.localizedDescription)")
                await MainActor.run { completion([]) }
            }
        }
    }
    
    private static func processRawData(_ data: Data, targetCount: Int) -> [Float] {
        let sampleCount = data.count / MemoryLayout<Int16>.size
        guard sampleCount > 0 else { return [] }
        
        return data.withUnsafeBytes { (buffer: UnsafeRawBufferPointer) in
            let ptr = buffer.bindMemory(to: Int16.self)
            var results = [Float]()
            
            // Use min-peak detection for more precision
            let chunkSize = max(1, sampleCount / targetCount)
            
            for i in 0..<targetCount {
                let start = i * chunkSize
                let end = min(start + chunkSize, sampleCount)
                var peak: Float = 0
                
                // Find the actual peak in this chunk
                for j in start..<end {
                    let magnitude = abs(Float(ptr[j]))
                    peak = max(peak, magnitude)
                }
                
                // Normalize to 0-1 range
                let normalized = peak / Float(Int16.max)
                results.append(max(0.02, normalized)) // Minimum visibility
            }
            return results
        }
    }
}

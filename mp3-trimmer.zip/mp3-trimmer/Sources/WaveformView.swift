import SwiftUI

struct WaveformView: View {
    let duration: Double
    let startTime: Double
    let endTime: Double
    let currentTime: Double
    let isPlaying: Bool
    let waveformSamples: [Float]
    @ObservedObject var viewModel: AudioEditorViewModel
    
    var body: some View {
        GeometryReader { geometry in
            let width = geometry.size.width
            let height = geometry.size.height
            
            ZStack(alignment: .leading) {
                // Background
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.black.opacity(0.4))
                    .frame(height: 140)
                
                // Rendered waveform bars
                HStack(spacing: 2) {
                    ForEach(Array(waveformSamples.enumerated()), id: \.offset) { _, magnitude in
                        let barHeight = max(4, CGFloat(magnitude) * 120)
                        Capsule()
                            .fill(Color.cyan.opacity(0.8))
                            .frame(width: 3, height: barHeight)
                    }
                }
                .frame(width: width, height: 140, alignment: .center)
                
                // Trimming selection overlay
                let startRatio = duration > 0 ? startTime / duration : 0
                let endRatio = duration > 0 ? endTime / duration : 1
                let selectionStart = startRatio * width
                let selectionEnd = endRatio * width
                let selectionWidth = max(selectionEnd - selectionStart, 0)
                
                // Dimmed inactive regions
                Rectangle()
                    .fill(Color.black.opacity(0.5))
                    .frame(width: selectionStart, height: 140)
                
                Rectangle()
                    .fill(Color.black.opacity(0.5))
                    .frame(width: max(0, width - selectionEnd), height: 140)
                    .offset(x: selectionEnd)
                
                // Yellow Selection Box
                RoundedRectangle(cornerRadius: 4)
                    .stroke(Color.yellow, lineWidth: 3)
                    .frame(width: selectionWidth, height: 140)
                    .offset(x: selectionStart)
                
                // Playhead
                let playheadX = duration > 0 ? (currentTime / duration) * width : 0
                Rectangle()
                    .fill(Color.red)
                    .frame(width: 2, height: 140)
                    .offset(x: playheadX)
            }
        }
        .frame(height: 160)
    }
}
